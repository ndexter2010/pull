# The ONE

The Opportunistic Network Environment simulator.

For instructions on how to get started, see [README](https://github.com/akeranen/the-one/wiki/README).
