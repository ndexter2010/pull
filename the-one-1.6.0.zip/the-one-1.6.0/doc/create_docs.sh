javadoc -sourcepath ../ -subpackages core:ui:gui:input:movement:report:routing:applications:interfaces
